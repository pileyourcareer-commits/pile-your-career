'use client';

import { useState } from 'react';

interface Message {
  sender: 'student' | 'ai';
  text: string;
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: 'Hello! I am your AI Career Assistant. Ask me anything about entrance exams in India, picking study streams, or mapping out the skills you need for a target career!'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);

  // High-Speed Local AI Knowledge Response Grid
  const getAIResponse = (query: string): string => {
    const cleanQuery = query.toLowerCase();
    
    if (cleanQuery.includes('ca') || cleanQuery.includes('chartered')) {
      return 'To become a Chartered Accountant (CA) in India, you need to clear three stages: CA Foundation, CA Intermediate, and the CA Final Exam. It also requires a mandatory 2-year practical articleship training period under a practicing CA.';
    }
    if (cleanQuery.includes('software') || cleanQuery.includes('engineer') || cleanQuery.includes('code')) {
      return 'For a Software Engineering career track, the core skills you need are Data Structures & Algorithms (DSA), a reliable backend/frontend stack (like Next.js and TypeScript), and database handling. Most students target B.Tech or BCA/MCA degree routes via entrance exams like JEE Main.';
    }
    if (cleanQuery.includes('exam') || cleanQuery.includes('entrance') || cleanQuery.includes('cuet')) {
      return 'Major entrance exams in India include CUET (for central university commerce/arts programs), JEE Main & Advanced (for engineering programs), and the UPSC Civil Services Exam (for elite government administrative roles like IAS/IPS).';
    }
    if (cleanQuery.includes('ias') || cleanQuery.includes('upsc') || cleanQuery.includes('civil')) {
      return 'The UPSC Civil Services Exam maps out into three distinct testing phases: Prelims (objective checks), Mains (detailed written essays), and the final expert Interview Panel stage. Any graduation degree qualifies you to apply.';
    }
    
    return 'That is a great career query! To explore this path, I highly recommend tracking the basic educational qualifications needed in India, checking if there is a specific entrance exam, and listing the top 3 digital skills you need to build a portfolio.';
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const studentMessage = inputValue;
    setMessages((prev) => [...prev, { sender: 'student', text: studentMessage }]);
    setInputValue('');
    setLoading(true);

    // Simulate standard conversational network loading delay
    setTimeout(() => {
      const responseText = getAIResponse(studentMessage);
      setMessages((prev) => [...prev, { sender: 'ai', text: responseText }]);
      setLoading(false);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6 flex flex-col justify-between max-w-4xl mx-auto">
      
      {/* Dynamic Header Module */}
      <header className="mb-6">
        <button 
          onClick={() => { window.location.href = '/dashboard'; }}
          className="text-xs font-bold text-blue-600 hover:underline mb-2 inline-block bg-transparent border-none cursor-pointer"
        >
          ← Back to Student Dashboard
        </button>
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">AI Career Assistance</h2>
        <p className="text-slate-500 text-sm mt-1">Chat with your personalized career tutor to uncover skill gaps and streamline entrance exam goals.</p>
      </header>

      {/* Main Conversation Chat Box Window Panel */}
      <div className="flex-1 bg-white border border-slate-200 shadow-sm rounded-xl p-6 flex flex-col justify-between min-h-[400px] mb-4">
        
        {/* Messages Stream Content Area */}
        <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`flex ${msg.sender === 'student' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-md rounded-xl p-4 text-sm leading-relaxed shadow-sm ${
                  msg.sender === 'student'
                    ? 'bg-blue-600 text-white rounded-br-none'
                    : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200'
                }`}
              >
                <span className="text-[10px] font-bold block uppercase tracking-wider mb-1 opacity-60">
                  {msg.sender === 'student' ? 'You' : 'AI Career Assistant'}
                </span>
                {msg.text}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-slate-100 text-slate-400 rounded-xl rounded-bl-none border border-slate-200 p-3 text-xs italic animate-pulse font-medium">
                AI Assistant is typing a matching advice node...
              </div>
            </div>
          )}
        </div>

        {/* Input Interactive Form Controls Bar */}
        <form onSubmit={handleSendMessage} className="border-t border-slate-100 pt-4 flex gap-3">
          <input
            type="text"
            required
            className="flex-1 px-4 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50/50"
            placeholder="Ask a question (e.g., How do I become a CA? What skills do software engineers need?)..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <button
            type="submit"
            className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm px-5 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer"
          >
            Send Message
          </button>
        </form>

      </div>
    </div>
  );
}