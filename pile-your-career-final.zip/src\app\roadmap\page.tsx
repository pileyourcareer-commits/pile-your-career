'use client';

import { useState } from 'react';

interface TimelineStep {
  phase: string;
  title: string;
  duration: string;
  objectives: string[];
  status: 'completed' | 'current' | 'upcoming';
}

interface CareerTrack {
  name: string;
  stream: string;
  steps: TimelineStep[];
}

export default function CareerRoadmapPage() {
  const [selectedTrack, setSelectedTrack] = useState<'ca' | 'tech'>('ca');

  // Pre-configured structured roadmap datasets for Indian paths
  const roadmaps: Record<'ca' | 'tech', CareerTrack> = {
    ca: {
      name: 'Chartered Accountant (CA) Journey',
      stream: 'Commerce Track',
      steps: [
        {
          phase: 'Phase 1',
          title: '12th standard & CA Foundation Examination',
          duration: '6 - 12 Months',
          objectives: ['Clear 12th standard commerce streams.', 'Register with ICAI for the CA Foundation test.', 'Pass 4 basic objective papers (Accounting, Law, Math, Economics).'],
          status: 'current'
        },
        {
          phase: 'Phase 2',
          title: 'CA Intermediate & Graduation Entry',
          duration: '9 Months Prep',
          objectives: ['Join a local B.Com graduation program alongside.', 'Clear Group 1 & Group 2 examinations of CA Intermediate.', 'Complete mandatory soft-skills training (ICITSS).'],
          status: 'upcoming'
        },
        {
          phase: 'Phase 3',
          title: 'Practical Articleship Training',
          duration: '2 Years continuous',
          objectives: ['Secure practical training placement under a practicing CA.', 'Gain real experience in corporate audit trails and taxation filing.', 'Balance practical industry execution with advanced test prep.'],
          status: 'upcoming'
        },
        {
          phase: 'Phase 4',
          title: 'CA Final Examination & Licensing',
          duration: '6 Months Final Push',
          objectives: ['Pass both advanced groups of the CA Final exam.', 'Acquire official membership registration code numbers from ICAI.', 'Step into corporate leadership positions.'],
          status: 'upcoming'
        }
      ]
    },
    tech: {
      name: 'Full Stack Software Engineer Journey',
      stream: 'Technology Track',
      steps: [
        {
          phase: 'Phase 1',
          title: 'Higher Secondary School Coding Focus',
          duration: '12 Months',
          objectives: ['Maintain high percentage focus in PCM subjects.', 'Clear local state/national entrance tests (JEE Main, MHT-CET).', 'Learn basic foundations of programming logic structures.'],
          status: 'current'
        },
        {
          phase: 'Phase 2',
          title: 'Higher Education (B.Tech / B.E. / BCA-MCA)',
          duration: '3 - 4 Years',
          objectives: ['Acquire structural core logic skills in Data Structures & Algorithms.', 'Build real application profiles using modern frameworks (Next.js, TypeScript).', 'Maintain healthy college CGPA score points.'],
          status: 'upcoming'
        },
        {
          phase: 'Phase 3',
          title: 'Portfolio Engineering & Open Internships',
          duration: '6 - 12 Months',
          objectives: ['Contribute actively to public developer communities.', 'Secure real industrial internship positions.', 'Host live web software applications online.'],
          status: 'upcoming'
        }
      ]
    }
  };

  const activeTrack = roadmaps[selectedTrack];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6">
      <div className="max-w-4xl mx-auto">
        
        {/* Dashboard Header Bar */}
        <header className="mb-8">
          <button 
            onClick={() => { window.location.href = '/dashboard'; }}
            className="text-xs font-bold text-blue-600 hover:underline mb-2 inline-block bg-transparent border-none cursor-pointer"
          >
            ← Back to Student Dashboard
          </button>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">My Career Roadmap</h2>
          <p className="text-slate-500 text-sm mt-1">Visualize your customized step-by-step career path trajectory from school up to industrial landing.</p>
        </header>

        {/* Track Selector Panel Controller Desk */}
        <div className="bg-white border border-slate-200 shadow-sm rounded-xl p-5 mb-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-md font-bold text-slate-800">{activeTrack.name}</h4>
            <p className="text-xs text-slate-400 mt-0.5">Stream Mapping: {activeTrack.stream}</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedTrack('ca')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                selectedTrack === 'ca'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              Chartered Accountant Map
            </button>
            <button
              onClick={() => setSelectedTrack('tech')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                selectedTrack === 'tech'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              Software Engineer Map
            </button>
          </div>
        </div>

        {/* Vertical Timeline Node Tree Layout */}
        <div className="relative border-l-2 border-slate-200 ml-4 pl-8 space-y-8 my-6">
          {activeTrack.steps.map((step, idx) => (
            <div key={idx} className="relative group">
              
              {/* Chronological Circle Anchor Badge */}
              <span className={`absolute -left-[41px] top-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center text-[10px] font-bold shadow-sm transition-transform group-hover:scale-110 ${
                step.status === 'current'
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-white text-slate-400 border-slate-200'
              }`}>
                {idx + 1}
              </span>

              {/* Timeline Info Step Box Panel */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:border-slate-300 transition-all">
                <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-100 mb-4">
                  <div>
                    <span className="text-[10px] font-extrabold text-blue-600 tracking-wider uppercase">{step.phase}</span>
                    <h4 className="text-lg font-bold text-slate-800 tracking-tight mt-0.5">{step.title}</h4>
                  </div>
                  <span className="px-2.5 py-0.5 bg-slate-100 text-slate-600 font-semibold text-xs rounded-full border border-slate-200 self-start sm:self-center">
                    ⏱️ {step.duration}
                  </span>
                </header>

                {/* Sub Objective Listing Fields */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Key Performance Milestones:</span>
                  <ul className="space-y-1.5">
                    {step.objectives.map((obj, oIdx) => (
                      <li key={oIdx} className="flex items-start gap-2.5 text-xs text-slate-600 leading-relaxed">
                        <span className="text-blue-500 font-bold mt-0.5">▪</span>
                        {obj}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </div>
  );
}