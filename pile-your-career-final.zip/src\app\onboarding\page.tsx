'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function OnboardingPage() {
  const [age, setAge] = useState('');
  const [educationBoard, setEducationBoard] = useState('HSC Commerce');
  const [careerGoalStatus, setCareerGoalStatus] = useState('unsure');
  const [parentEmail, setParentEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleOnboardingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) throw new Error('No active student session detected. Please log in.');

      const parsedAge = parseInt(age);
      const requiresParentalConsent = parsedAge < 18;

      const updateData = {
        age: parsedAge,
        education_board: educationBoard,
        career_goal_status: careerGoalStatus,
        parent_consent: !requiresParentalConsent,
      };

      const { error: updateError } = await supabase.from('profiles').update(updateData).eq('id', user.id);
      if (updateError) throw updateError;

      window.location.href = '/dashboard';
    } catch (err: any) {
      setError(err.message || 'Error saving onboarding profile configurations.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-md p-8 border border-slate-200">
        <div className="w-12 h-2 bg-blue-600 rounded-full mb-4"></div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Customize Your Journey</h2>
        <p className="text-slate-500 text-sm mb-6">Let's set up your profile path. Answer only what is relevant to you.</p>

        {error && (
          <div className="bg-rose-50 text-rose-700 p-3 rounded-lg text-sm mb-4 border border-rose-200">
            {error}
          </div>
        )}

        <form onSubmit={handleOnboardingSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Your Age</label>
            <input
              type="number"
              required
              min={10}
              max={100}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-slate-800 text-sm"
              placeholder="e.g., 17"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />
          </div>

          {age && parseInt(age) < 18 && (
            <div className="p-4 bg-amber-50 rounded-lg border border-amber-200 animate-fadeIn">
              <label className="block text-sm font-medium text-amber-800 mb-1">Parent / Guardian Email</label>
              <p className="text-xs text-amber-600 mb-2">Parental consent notification is required under safe data protocols.</p>
              <input
                type="email"
                required
                className="w-full px-3 py-2 border border-amber-300 rounded-lg bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none text-slate-800 text-sm"
                placeholder="parent@example.com"
                value={parentEmail}
                onChange={(e) => setParentEmail(e.target.value)}
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Current Education Board / Stream</label>
            <select
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-slate-800 text-sm bg-white"
              value={educationBoard}
              onChange={(e) => setEducationBoard(e.target.value)}
            >
              <option value="HSC Commerce">12th HSC Commerce (Maharashtra)</option>
              <option value="CBSE Commerce">CBSE Commerce</option>
              <option value="ICSE / ISC">ISC Commerce</option>
              <option value="Other Stream">Other Stream / Board</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Which statement describes you best?</label>
            <div className="space-y-2">
              {[
                { value: 'known', label: 'I know my career goal completely' },
                { value: 'few_ideas', label: 'I have a few ideas I am choosing between' },
                { value: 'unsure', label: 'I am not sure yet (Don\'t worry, we will explore!)' }
              ].map((option) => (
                <label
                  key={option.value}
                  className={`flex items-start p-3 border rounded-lg cursor-pointer transition-all ${
                    careerGoalStatus === option.value
                      ? 'border-blue-600 bg-blue-50/50'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="careerGoalStatus"
                    className="mt-1 mr-3 text-blue-600 focus:ring-blue-500"
                    value={option.value}
                    checked={careerGoalStatus === option.value}
                    onChange={() => setCareerGoalStatus(option.value)}
                  />
                  <span className="text-sm font-medium text-slate-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors text-sm disabled:bg-slate-400 mt-4 shadow-sm"
          >
            {loading ? 'Saving adjustments...' : 'Continue to Dashboard'}
          </button>
        </form>
      </div>
    </div>
  );
}
