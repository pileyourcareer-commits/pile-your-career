'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function DashboardPage() {
  const [studentName, setStudentName] = useState('Student');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProfileData() {
      try {
        const { data: { user }, error: userError } = await supabase.auth.getUser();
        if (userError || !user) return;

        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', user.id)
          .single();

        if (profile?.full_name) {
          setStudentName(profile.full_name);
        }
      } catch (err) {
        console.error('Error fetching dashboard parameters:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchProfileData();
  }, []);

  const coreFeatures = [
    { id: 1, title: 'Discover My Interests', desc: 'Take a quick choice matrix test to map your core professional values.', icon: '🎯', color: 'bg-rose-50 border-rose-200 text-rose-600' },
    { id: 2, title: 'Explore Careers', desc: 'Browse 30+ detailed high-demand paths, entrance tests, and requirements in India.', icon: '💼', color: 'bg-blue-50 border-blue-200 text-blue-600' },
    { id: 3, title: 'Career Organizer', desc: 'Manage milestones, clear tasks, set targets, and track planning calendars.', icon: '📅', color: 'bg-emerald-50 border-emerald-200 text-emerald-600' },
    { id: 4, title: 'Colleges & Universities', desc: 'Filter through 50+ major Indian learning hubs by budget and qualifying marks.', icon: '🏛️', color: 'bg-indigo-50 border-indigo-200 text-indigo-600' },
    { id: 5, title: 'My Career Roadmap', desc: 'Visualize your customized continuous career path from 12th standard onward.', icon: '🗺️', color: 'bg-amber-50 border-amber-200 text-amber-600' },
    { id: 6, title: 'AI Career Assistance', desc: 'Chat directly with your interactive tutor for skill-gap tracking queries.', icon: '🤖', color: 'bg-purple-50 border-purple-200 text-purple-600' }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <p className="text-slate-600 font-medium text-sm animate-pulse">Loading dashboard canvas layout...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <nav className="bg-white border-b border-slate-200 px-6 py-4 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Pile Your Career</h1>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold shadow-sm">
              {studentName.charAt(0).toUpperCase()}
            </div>
            <span className="text-sm font-medium text-slate-700">Hello, {studentName}!</span>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <header className="mb-8">
          <h2 className="text-3xl font-extrabold text-slate-900 mb-2">Your Career Roadmap Map</h2>
          <p className="text-slate-500 text-sm">Select a functional control panel feature area below to build your career journey timeline.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {coreFeatures.map((feature) => (
            <div
              key={feature.id}
              className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-md transition-all flex flex-col justify-between group hover:border-slate-300"
            >
              <div>
                <div className={`w-12 h-12 rounded-lg border ${feature.color} flex items-center justify-center text-2xl mb-4 group-hover:scale-105 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-lg font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-slate-500 text-xs leading-relaxed mb-4">
                  {feature.desc}
                </p>
              </div>
              <button 
                onClick={() => alert(`${feature.title} workspace coming up next!`)}
                className="w-full mt-2 text-center bg-slate-50 border border-slate-200 hover:bg-blue-600 hover:text-white text-slate-700 text-xs font-semibold py-2 rounded-lg transition-all"
              >
                Open Workspace
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
