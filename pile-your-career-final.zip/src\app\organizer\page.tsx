'use client';

import { useState } from 'react';

interface Task {
  id: number;
  text: string;
  completed: boolean;
}

interface Milestone {
  id: string;
  title: string;
  timeline: string;
  tasks: Task[];
}

export default function CareerOrganizerPage() {
  const [activeTab, setActiveTab] = useState<'timeline' | 'add'>('timeline');
  const [milestones, setMilestones] = useState<Milestone[]>([
    {
      id: 'm1',
      title: '12th HSC Commerce Board Preparation',
      timeline: 'Months 1 - 3',
      tasks: [
        { id: 101, text: 'Complete past 5 years question papers for Book-keeping & Accountancy.', completed: false },
        { id: 102, text: 'Review core Economics micro & macro structural definitions.', completed: false },
        { id: 103, text: 'Take a full-length English language revision mock test.', completed: false }
      ]
    },
    {
      id: 'm2',
      title: 'Entrance Examinations & Registration Window',
      timeline: 'Months 4 - 6',
      tasks: [
        { id: 201, text: 'Register for CA Foundation / target university entrance modules.', completed: false },
        { id: 202, text: 'Gather qualifying score cards, stream receipts, and identity tokens.', completed: false }
      ]
    }
  ]);

  // New Custom Milestone Form States
  const [newTitle, setNewTitle] = useState('');
  const [newTimeline, setNewTimeline] = useState('Months 1 - 3');
  const [newTaskText, setNewTaskText] = useState('');

  // Toggle Task Completion State Logic
  const handleToggleTask = (milestoneId: string, taskId: number) => {
    setMilestones((prevMilestones) =>
      prevMilestones.map((milestone) => {
        if (milestone.id !== milestoneId) return milestone;
        return {
          ...milestone,
          tasks: milestone.tasks.map((task) =>
            task.id === taskId ? { ...task, completed: !task.completed } : task
          )
        };
      })
    );
  };

  // Add Custom User Milestones
  const handleCreateMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const createdMilestone: Milestone = {
      id: `custom_${Date.now()}`,
      title: newTitle,
      timeline: newTimeline,
      tasks: newTaskText.trim() 
        ? [{ id: Date.now(), text: newTaskText, completed: false }]
        : []
    };

    setMilestones((prev) => [...prev, createdMilestone]);
    setNewTitle('');
    setNewTaskText('');
    setActiveTab('timeline');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6">
      <div className="max-w-4xl mx-auto">
        
        {/* Header Dashboard Navigation Panel */}
        <header className="mb-8">
          <button 
            onClick={() => { window.location.href = '/dashboard'; }}
            className="text-xs font-bold text-blue-600 hover:underline mb-2 inline-block bg-transparent border-none cursor-pointer"
          >
            ← Back to Student Dashboard
          </button>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Career Organizer</h2>
          <p className="text-slate-500 text-sm mt-1">Manage active deadlines, create custom target sheets, and check off educational milestones.</p>
        </header>

        {/* Tab Toggle Navigation Bar */}
        <div className="flex border-b border-slate-200 mb-6">
          <button
            onClick={() => setActiveTab('timeline')}
            className={`py-2.5 px-4 text-sm font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'timeline'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Active Milestone Timeline Map
          </button>
          <button
            onClick={() => setActiveTab('add')}
            className={`py-2.5 px-4 text-sm font-semibold border-b-2 transition-all cursor-pointer ${
              activeTab === 'add'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            + Create Custom Milestone Target
          </button>
        </div>

        {/* Workspace Display Blocks */}
        {activeTab === 'timeline' ? (
          <div className="space-y-6">
            {milestones.length === 0 ? (
              <p className="text-slate-400 italic text-center py-8">Your planning board is currently clear.</p>
            ) : (
              milestones.map((milestone) => (
                <div key={milestone.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                  <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3 mb-4">
                    <h4 className="text-md font-bold text-slate-900">{milestone.title}</h4>
                    <span className="px-2.5 py-0.5 bg-slate-100 text-slate-600 font-semibold text-xs rounded-full border border-slate-200">
                      {milestone.timeline}
                    </span>
                  </header>

                  {/* Checklist Sub-Task Channels */}
                  <div className="space-y-2">
                    {milestone.tasks.length === 0 ? (
                      <p className="text-slate-400 text-xs italic">No specific sub-tasks added to this target tier yet.</p>
                    ) : (
                      milestone.tasks.map((task) => (
                        <label
                          key={task.id}
                          className={`flex items-start gap-3 p-3 rounded-lg border transition-all cursor-pointer select-none ${
                            task.completed
                              ? 'bg-slate-50 border-slate-200 opacity-60'
                              : 'bg-white border-slate-100 hover:bg-slate-50/50'
                          }`}
                        >
                          <input
                            type="checkbox"
                            className="mt-0.5 rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                            checked={task.completed}
                            onChange={() => handleToggleTask(milestone.id, task.id)}
                          />
                          <span className={`text-sm ${task.completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                            {task.text}
                          </span>
                        </label>
                      ))
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          /* Create Milestone Form Sheet Container */
          <form onSubmit={handleCreateMilestone} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">Milestone Action Objective</label>
              <input
                type="text"
                required
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white shadow-sm"
                placeholder="e.g., CA Foundation Accountancy Module Prep"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">Target Execution Windows</label>
              <select
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white shadow-sm"
                value={newTimeline}
                onChange={(e) => setNewTimeline(e.target.value)}
              >
                <option value="Months 1 - 3">Months 1 - 3 (Immediate Focus)</option>
                <option value="Months 4 - 6">Months 4 - 6 (Mid Term Action)</option>
                <option value="Months 7 - 12">Months 7 - 12 (Long Horizon Targets)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">Initial Primary Task Sub-item (Optional)</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white shadow-sm"
                placeholder="e.g., Purchase core syllabus textbooks..."
                value={newTaskText}
                onChange={(e) => setNewTaskText(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="w-full mt-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm py-2 rounded-lg shadow-sm transition-all cursor-pointer"
            >
              Add Milestone Card to Tracking Canvas
            </button>
          </form>
        )}

      </div>
    </div>
  );
}
