'use client';

import { useState } from 'react';

interface Career {
  id: string;
  title: string;
  category: 'Commerce' | 'Technology' | 'Arts' | 'Public Service';
  responsibilities: string;
  exams: string;
  qualifications: string;
  resources: string;
}

export default function ExploreCareersPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCareer, setSelectedCareer] = useState<Career | null>(null);

  const careerDatabase: Career[] = [
    {
      id: 'chartered-accountant',
      title: 'Chartered Accountant (CA)',
      category: 'Commerce',
      responsibilities: 'Auditing financial records, managing corporate taxation, financial planning, and business consulting.',
      exams: 'CA Foundation, CA Intermediate, and CA Final (Conducted by ICAI).',
      qualifications: '12th standard clear (any stream, Commerce preferred) followed by registering with ICAI.',
      resources: 'Official Institute of Chartered Accountants of India portal (icai.org).'
    },
    {
      id: 'software-engineer',
      title: 'Software Engineer / Developer',
      category: 'Technology',
      responsibilities: 'Writing code architectures, designing web applications, debugging software systems, and engineering backend data pipes.',
      exams: 'JEE Main, JEE Advanced, MHT-CET, or institutional entrance tests.',
      qualifications: '12th standard clear with Physics, Chemistry, and Mathematics (PCM), followed by a B.E./B.Tech or BCA/MCA degree.',
      resources: 'NPTEL platform tutorials, official programming documentation, and open-source learning paths.'
    },
    {
      id: 'data-analyst',
      title: 'Data Analyst',
      category: 'Technology',
      responsibilities: 'Interpreting complex data structures, cleaning statistics, creating interactive dashboards, and identifying business performance trends.',
      exams: 'Not stream-restricted; specific university engineering/science entrance tests apply.',
      qualifications: 'Degree in Computer Science, Statistics, Mathematics, or Commerce with analytics certifications.',
      resources: 'Google Data Analytics Certification tracks and free Kaggle open tutorials.'
    },
    {
      id: 'civil-servant',
      title: 'Civil Servant (IAS / IPS)',
      category: 'Public Service',
      responsibilities: 'Implementing government welfare policies, managing regional law and order, and leading civil administration frameworks.',
      exams: 'UPSC Civil Services Examination (Preliminary, Mains, and Interview panel stages).',
      qualifications: 'A graduation degree in any stream or subject from a recognized Indian university.',
      resources: 'Official Union Public Service Commission portal (upsc.gov.in).'
    },
    {
      id: 'digital-marketer',
      title: 'Digital Marketing Specialist',
      category: 'Arts',
      responsibilities: 'Managing search engine optimization (SEO), orchestrating ad campaigns, content creation tracking, and brand growth analytics.',
      exams: 'No official state entrance tests; brand portfolio evaluations carry primary weight.',
      qualifications: '12th standard clear or graduate in any stream (BBA or Mass Media profiles preferred).',
      resources: 'Google Digital Unlocked modules and free Meta Blueprint certification options.'
    }
  ];

  const filteredCareers = careerDatabase.filter((career) => {
    const matchesSearch = career.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          career.responsibilities.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || career.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6">
      <div className="max-w-6xl mx-auto">
        
        <header className="mb-8">
          <button 
            onClick={() => { window.location.href = '/dashboard'; }}
            className="text-xs font-bold text-blue-600 hover:underline mb-2 inline-block bg-transparent border-none cursor-pointer"
          >
            ← Back to Student Dashboard
          </button>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Explore Careers</h2>
          <p className="text-slate-500 text-sm mt-1">Browse high-demand Indian career tracks, required entrance evaluations, and verified milestones.</p>
        </header>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <input
            type="text"
            className="flex-1 px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white shadow-sm"
            placeholder="Search by career title or keywords..."
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); }}
          />
          <div className="flex gap-2 overflow-x-auto pb-1">
            {['All', 'Commerce', 'Technology', 'Arts', 'Public Service'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => { setSelectedCategory(cat); }}
                className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-1 space-y-4">
            {filteredCareers.length === 0 ? (
              <p className="text-slate-400 text-sm italic p-4 bg-white rounded-xl border border-slate-200 text-center">No careers found matching your criteria.</p>
            ) : (
              filteredCareers.map((career) => (
                <div
                  key={career.id}
                  onClick={() => { setSelectedCareer(career); }}
                  className={`p-5 rounded-xl border cursor-pointer transition-all shadow-sm bg-white hover:border-slate-300 ${
                    selectedCareer?.id === career.id ? 'ring-2 ring-blue-600 border-transparent' : 'border-slate-200'
                  }`}
                >
                  <span className="text-xs font-bold text-slate-400 tracking-wider uppercase">{career.category}</span>
                  <h4 className="text-md font-bold text-slate-800 mt-1 mb-2">{career.title}</h4>
                  <p className="text-slate-500 text-xs line-clamp-2 leading-relaxed">{career.responsibilities}</p>
                </div>
              ))
            )}
          </div>

          <div className="lg:col-span-2">
            {selectedCareer ? (
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-8 sticky top-24">
                <span className="px-2.5 py-1 bg-blue-50 text-blue-700 text-xs font-bold rounded-md border border-blue-100 uppercase">{selectedCareer.category} Stream</span>
                <h3 className="text-2xl font-bold text-slate-900 mt-4 mb-6">{selectedCareer.title} Profile Blueprint</h3>
                
                <div className="space-y-6">
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Core Responsibilities</h5>
                    <p className="text-sm text-slate-700 leading-relaxed bg-slate-50/50 p-3 rounded-lg border border-slate-100">{selectedCareer.responsibilities}</p>
                  </div>

                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Required Qualifications (India)</h5>
                    <p className="text-sm text-slate-700 leading-relaxed bg-slate-50/50 p-3 rounded-lg border border-slate-100">{selectedCareer.qualifications}</p>
                  </div>

                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Target Entrance Examinations</h5>
                    <p className="text-sm font-semibold text-blue-700 leading-relaxed bg-blue-50/20 p-3 rounded-lg border border-blue-50">{selectedCareer.exams}</p>
                  </div>

                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Verified Information Reference Nodes</h5>
                    <p className="text-xs text-slate-500 italic">Source: {selectedCareer.resources}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => { alert(`Saved "${selectedCareer.title}" to Organizer workspace!`); }}
                  className="w-full mt-8 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs py-2.5 rounded-lg transition-all shadow-sm"
                >
                  Bookmark and Add to My Organizer Workspace
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 border-dashed p-12 text-center flex flex-col items-center justify-center min-h-[300px]">
                <span className="text-3xl mb-3">💼</span>
                <h4 className="text-md font-bold text-slate-700 mb-1">No Career Profile Selected</h4>
                <p className="text-slate-400 text-xs max-w-xs">Select any item template card from the catalog listing channel to view detailed eligibility vectors.</p>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
