'use client';

import { useState } from 'react';

interface College {
  id: string;
  name: string;
  location: string;
  stream: 'Commerce' | 'Technology' | 'Management' | 'Arts';
  annualFees: string;
  maxBudget: number; // numeric filter value in INR
  admissionCriteria: string;
}

export default function CollegesDirectoryPage() {
  const [selectedStream, setSelectedStream] = useState<string>('All');
  const [budgetLimit, setBudgetLimit] = useState<number>(300000); // 3 Lakhs default slider parameter

  // Seeded dataset representing prime Indian higher education destinations
  const collegeDatabase: College[] = [
    {
      id: 'srcc-delhi',
      name: 'Shri Ram College of Commerce (SRCC)',
      location: 'Delhi (Delhi University North Campus)',
      stream: 'Commerce',
      annualFees: '₹30,000 / year',
      maxBudget: 30000,
      admissionCriteria: 'CUET (Common University Entrance Test) high scores eligibility merit.'
    },
    {
      id: 'iit-bombay',
      name: 'Indian Institute of Technology (IIT) Bombay',
      location: 'Mumbai, Maharashtra',
      stream: 'Technology',
      annualFees: '₹2,200,000 / year',
      maxBudget: 220000,
      admissionCriteria: 'JEE Main followed by exceptional rank clear in JEE Advanced.'
    },
    {
      id: 'iim-ahmedabad',
      name: 'Indian Institute of Management (IIM) Ahmedabad',
      location: 'Ahmedabad, Gujarat',
      stream: 'Management',
      annualFees: '₹12,00,000 / year (Integrated IPM streams approximate)',
      maxBudget: 1200000,
      admissionCriteria: 'CAT exam or IPMAT qualification scores followed by strict interview panels.'
    },
    {
      id: 'st-xaviers-mumbai',
      name: 'St. Xavier\'s College',
      location: 'Mumbai, Maharashtra (Mumbai University)',
      stream: 'Arts',
      annualFees: '₹15,000 / year',
      maxBudget: 15000,
      admissionCriteria: '12th standard aggregate stream merit cutoffs or autonomous evaluation tests.'
    },
    {
      id: 'symbiosis-pune',
      name: 'Symbiosis Center for Management Studies (SCMS)',
      location: 'Pune, Maharashtra',
      stream: 'Management',
      annualFees: '₹3,50,000 / year',
      maxBudget: 350000,
      admissionCriteria: 'SET (Symbiosis Entrance Test) followed by group discussion criteria.'
    }
  ];

  // Algorithmic Filter Sorting System
  const filteredColleges = collegeDatabase.filter((college) => {
    const matchesStream = selectedStream === 'All' || college.stream === selectedStream;
    const matchesBudget = college.maxBudget <= budgetLimit;
    return matchesStream && matchesBudget;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6">
      <div className="max-w-5xl mx-auto">
        
        {/* Navigation Dashboard Header */}
        <header className="mb-8">
          <button 
            onClick={() => { window.location.href = '/dashboard'; }}
            className="text-xs font-bold text-blue-600 hover:underline mb-2 inline-block bg-transparent border-none cursor-pointer"
          >
            ← Back to Student Dashboard
          </button>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Colleges & Universities</h2>
          <p className="text-slate-500 text-sm mt-1">Filter matching higher education institutes across India by fees, stream layouts, and selection marks.</p>
        </header>

        {/* Dashboard Control Panel Desk Card */}
        <div className="bg-white border border-slate-200 shadow-sm rounded-xl p-6 mb-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Stream Selector Filter channel */}
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Select Study Stream</label>
            <div className="flex flex-wrap gap-2">
              {['All', 'Commerce', 'Technology', 'Management', 'Arts'].map((stream) => (
                <button
                  key={stream}
                  onClick={() => setSelectedStream(stream)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                    selectedStream === stream
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {stream}
                </button>
              ))}
            </div>
          </div>

          {/* Budget Limit Slider Channel */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Maximum Annual Fees Budget</label>
              <span className="text-sm font-bold text-blue-600">₹{budgetLimit.toLocaleString('en-IN')}</span>
            </div>
            <input
              type="range"
              min={15000}
              max={1500000}
              step={10000}
              className="w-full accent-blue-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
              value={budgetLimit}
              onChange={(e) => setBudgetLimit(parseInt(e.target.value))}
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-medium">
              <span>Min: ₹15k</span>
              <span>Mid: ₹7.5L</span>
              <span>Max: ₹15 Lakhs+</span>
            </div>
          </div>

        </div>

        {/* Dynamic Matrix Cards Display Channel */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredColleges.length === 0 ? (
            <div className="col-span-full bg-white rounded-xl border border-slate-200 border-dashed p-12 text-center flex flex-col items-center justify-center">
              <span className="text-3xl mb-2">🏛️</span>
              <h4 className="text-sm font-bold text-slate-700 mb-1">No Matching Institutes Found</h4>
              <p className="text-slate-400 text-xs max-w-xs">Try sliding your maximum budget value to a higher ceiling mark or shifting your stream tags selection.</p>
            </div>
          ) : (
            filteredColleges.map((college) => (
              <div key={college.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-md transition-all flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start gap-4 mb-3">
                    <span className="px-2 py-0.5 bg-slate-50 text-slate-600 text-[10px] font-bold rounded border border-slate-200 uppercase tracking-wider">
                      {college.stream} Track
                    </span>
                    <span className="text-sm font-bold text-emerald-600">{college.annualFees}</span>
                  </div>
                  <h4 className="text-lg font-bold text-slate-800 mb-1 tracking-tight">{college.name}</h4>
                  <p className="text-slate-400 text-xs font-medium mb-4">📍 {college.location}</p>
                  
                  <div className="border-t border-slate-100 pt-3 space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Admission Framework Requirements:</span>
                    <p className="text-xs text-slate-600 leading-relaxed">{college.admissionCriteria}</p>
                  </div>
                </div>
                
                <button
                  onClick={() => alert(`Redirecting out to localized tracking paths for ${college.name} coming tomorrow!`)}
                  className="w-full mt-6 text-center bg-slate-50 border border-slate-200 hover:bg-slate-900 hover:text-white hover:border-slate-900 text-slate-700 text-xs font-bold py-2 rounded-lg transition-all cursor-pointer"
                >
                  View Admission Criteria Node
                </button>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
}