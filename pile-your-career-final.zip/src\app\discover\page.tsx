'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabase';

interface Question {
  id: number;
  text: string;
  category: 'Technology' | 'Commerce' | 'Arts' | 'Public Service';
}

export default function DiscoverPage() {
  const [currentStep, setCurrentStep] = useState<'intro' | 'quiz' | 'results'>('intro');
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [saving, setSaving] = useState(false);
  const [topCategories, setTopCategories] = useState<string[]>([]);

  // 10 sample representative questions across major Indian study streams
  const questions: Question[] = [
    { id: 1, text: 'I enjoy managing pocket money budgets and tracking expenses.', category: 'Commerce' },
    { id: 2, text: 'I like building things, tinkering with computers, or exploring apps.', category: 'Technology' },
    { id: 3, text: 'I like sketch drawings, writing stories, or designing visual graphics.', category: 'Arts' },
    { id: 4, text: 'I want to work on social welfare, law enforcement, or civil administration.', category: 'Public Service' },
    { id: 5, text: 'I find corporate business case studies and stock market trends interesting.', category: 'Commerce' },
    { id: 6, text: 'I am curious about how software programs and websites operate behind the scenes.', category: 'Technology' },
    { id: 7, text: 'I enjoy playing musical instruments, photography, or creative arts.', category: 'Arts' },
    { id: 8, text: 'I like helping people solve local community problems or organizing social events.', category: 'Public Service' },
    { id: 9, text: 'I want to understand banking operations, taxation frameworks, or accounting.', category: 'Commerce' },
    { id: 10, text: 'I like setting up hardware networks, configuring gadgets, or logic loops.', category: 'Technology' }
  ];

  const handleScoreSelect = (questionId: number, score: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: score }));
  };

  const calculateResults = async () => {
    // Deterministic mathematical scoring engine calculation
    const totals: Record<string, number> = { Technology: 0, Commerce: 0, Arts: 0, 'Public Service': 0 };
    
    questions.forEach((q) => {
      const score = answers[q.id] || 0;
      totals[q.category] += score;
    });

    // Sort categories dynamically by highest absolute values
    const sortedCategories = Object.keys(totals).sort((a, b) => totals[b] - totals[a]);
    const primaryInterests = sortedCategories.slice(0, 2); // Pull top 2 areas
    
    setTopCategories(primaryInterests);
    setCurrentStep('results');
    setSaving(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        // Save the results historical record row directly into cloud sandbox
        await supabase.from('interest_results').insert({
          student_id: user.id,
          top_categories: primaryInterests,
          raw_scores: totals
        });
      }
    } catch (err) {
      console.error('Error saving assessment index scores:', err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6 flex items-center justify-center">
      <div className="max-w-2xl w-full bg-white border border-slate-200 shadow-sm rounded-xl p-8">
        
        {/* Step 1: Introduction Panel */}
        {currentStep === 'intro' && (
          <div className="text-center">
            <span className="text-3xl">🎯</span>
            <h2 className="text-2xl font-bold text-slate-900 mt-3 mb-2">Discover Your Core Interests</h2>
            <p className="text-slate-500 text-sm max-w-md mx-auto mb-6">
              This introductory assessment maps your personal baseline preferences across stream options. 
              Please note: This exploration path helps uncover preferences and is not a scientifically validated diagnostic tool.
            </p>
            <button
              onClick={() => setCurrentStep('quiz')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm px-6 py-2.5 rounded-lg transition-colors shadow-sm"
            >
              Start Free Discovery Quiz
            </button>
          </div>
        )}

        {/* Step 2: Interactive Assessment Form */}
        {currentStep === 'quiz' && (
          <div>
            <header className="border-b border-slate-100 pb-4 mb-6">
              <h3 className="text-lg font-bold text-slate-900">Interest Matching Matrix</h3>
              <p className="text-xs text-slate-400 mt-1">Rate each statement honestly based on your general preferences.</p>
            </header>

            <div className="space-y-6">
              {questions.map((q, idx) => (
                <div key={q.id} className="bg-slate-50/50 p-4 rounded-lg border border-slate-100">
                  <p className="text-sm font-semibold text-slate-800 mb-3">
                    {idx + 1}. {q.text}
                  </p>
                  <div className="grid grid-cols-5 gap-2 max-w-md">
                    {[1, 2, 3, 4, 5].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => handleScoreSelect(q.id, num)}
                        className={`py-1.5 px-3 text-xs font-medium border rounded-md transition-all ${
                          answers[q.id] === num
                            ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {num === 1 ? 'Dislike (1)' : num === 5 ? 'Love (5)' : num}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={calculateResults}
              disabled={Object.keys(answers).length < questions.length}
              className="w-full mt-8 bg-blue-600 hover:bg-blue-700 text-white disabled:bg-slate-300 font-semibold text-sm py-2.5 rounded-lg transition-all shadow-sm"
            >
              Calculate My Core Values
            </button>
          </div>
        )}

        {/* Step 3: Analytical Explanations Layout */}
        {currentStep === 'results' && (
          <div className="text-center">
            <span className="text-4xl animate-bounce inline-block">🚀</span>
            <h2 className="text-2xl font-bold text-slate-900 mt-3 mb-1">Your Interest Mapping Profile</h2>
            <p className="text-xs text-slate-400 mb-6">Calculated using matching matrix data values.</p>

            <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-6 text-left max-w-md mx-auto mb-6">
              <h4 className="text-xs font-bold text-blue-800 tracking-wider uppercase mb-3">Your Top 2 Domains:</h4>
              <ul className="space-y-2">
                {topCategories.map((cat, index) => (
                  <li key={cat} className="flex items-center gap-3 text-sm font-semibold text-slate-800">
                    <span className="w-5 h-5 bg-blue-600 text-white text-xs font-bold flex items-center justify-center rounded-full shadow-sm">
                      {index + 1}
                    </span>
                    {cat} Track
                  </li>
                ))}
              </ul>
            </div>

            <button
              onClick={() => (window.location.href = '/dashboard')}
              className="text-slate-600 hover:text-blue-600 text-xs font-bold underline transition-colors"
            >
              Return to Control Panel Dashboard
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
